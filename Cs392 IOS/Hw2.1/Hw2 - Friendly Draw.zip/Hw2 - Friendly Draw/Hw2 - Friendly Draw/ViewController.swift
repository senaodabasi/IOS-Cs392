//
//  ViewController.swift
//  Hw2 - Friendly Draw
//
//  Created by Sena Odabaşı on 15/10/2017.
//  Copyright © 2017 Sena Odabaşı. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var listLabel: UILabel!
    @IBOutlet weak var listlabel2: UILabel!
    @IBOutlet weak var listLabel3: UILabel!
    @IBOutlet weak var drawButton: UIButton!
    @IBOutlet weak var clearButton: UIButton!
    
    var nameArray : [String] = []
    var usedNameArray : [String] = []
    var count : Int = 1
    
    func assignNames(){
        nameArray.removeAll()
        nameArray = ["Lonely Island", "Michael Jackson", "Elvis Presley", "Radiohead", "Queen", "Rolling Stones", "The Animals", "Adele","Survivor", "Beatles" ]
    }
    
    func pickRandomName() -> String{
        let nameIndex =  arc4random_uniform(UInt32(nameArray.count))
        var name = nameArray[Int(nameIndex)]
        nameArray.remove(at: Int(nameIndex))
        return name
    }
    
    @IBAction func draw(_ sender: UIButton) {
        if(count == 1){
        var name = String(pickRandomName())
        listLabel.lineBreakMode = NSLineBreakMode.byWordWrapping
        listLabel.text = "\(count)   \(name)"
        count = count + 1
        }else if(count == 2){
            var name = String(pickRandomName())
            listlabel2.lineBreakMode = NSLineBreakMode.byWordWrapping
            listlabel2.text = "\(count)   \(name)"
            count = count + 1
        }else if(count == 3){
        var name = String(pickRandomName())
        listLabel3.lineBreakMode = NSLineBreakMode.byWordWrapping
        listLabel3.text = "\(count)   \(name)"
        count = count + 1
        }
    }
    
    
    @IBAction func clear(_ sender: UIButton) {
        assignNames()
        count = 1
        listLabel.text = ""
        listlabel2.text = ""
        listLabel3.text = ""
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        assignNames()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

