//
//  ViewController.swift
//  CardGame
//
//  Created by Gun Makinabakan on 5.10.2017.
//  Copyright © 2017 Gun Makinabakan. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var player1CardImageView: UIImageView!
    
    @IBOutlet weak var player2CardImageView: UIImageView!
    
    @IBOutlet weak var resultLabel: UILabel!
    
    @IBOutlet weak var playButton: UIButton!
    
    
    var cardArray : [Int] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
       shuffleDeck()
    }
    
    func drawCard() -> Int {
        let cardIndex = arc4random_uniform(UInt32(cardArray.count))
        let cardValue = cardArray[Int(cardIndex)]
        cardArray.remove(at: Int(cardIndex))
        return cardValue
    }
    
    func shuffleDeck(){
        cardArray.removeAll()
        for var i in stride(from: 1, to: 13, by: 1){
            cardArray.append(i)
        }
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func playTheGame(_ sender: Any) {
        print("Play")
        
        if(cardArray.count < 2)
        {
            shuffleDeck()
        }
        
        let player1Card = drawCard()
        let player2Card = drawCard()
        
        player1CardImageView.image = UIImage(named: "card\(player1Card)")
        player2CardImageView.image = UIImage(named: "card\(player2Card)")
        
        if(player1Card > player2Card)
        {
            resultLabel.text = "Player 1 wins!"
        }
        else
        {
            resultLabel.text = "Player 2 wins"
        }
        
        if(cardArray.count < 2)
        {
            playButton.setTitle("Play Again", for: .normal)
        }
        else
        {
            playButton.setTitle("Play", for: .normal)
        }
        
    }
    
    
}

