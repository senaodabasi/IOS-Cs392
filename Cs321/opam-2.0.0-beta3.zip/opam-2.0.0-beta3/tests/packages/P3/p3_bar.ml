let f () =
  Printf.printf "foo\n%!"

let _ =
  P3.z ()
